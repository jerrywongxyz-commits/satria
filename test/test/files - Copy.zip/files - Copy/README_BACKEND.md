# Backend Satpol PP Kaltara

Backend ini memakai Node.js native tanpa dependency eksternal.

## Menjalankan

```powershell
node server.js
```

Jika `node` WindowsApps ditolak, gunakan runtime bawaan Codex:

```powershell
C:\Users\jerry\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe server.js
```

Lalu buka:

- Website: `http://127.0.0.1:8765/`
- Health check: `http://127.0.0.1:8765/api/health`
- Admin panel: login dari tombol `Masuk Admin` di website publik

## Endpoint Utama

- `POST /api/login`
- `GET /api/me`
- `POST /api/logout`
- `GET /api/pengaduan`
- `POST /api/pengaduan`
- `GET /api/pengaduan/:ticket`
- `GET /api/berita`
- `POST/PATCH/DELETE /api/berita`
- `GET /api/agenda`
- `POST/PATCH/DELETE /api/agenda`
- `GET /api/galeri`
- `POST/PATCH/DELETE /api/galeri`
- `GET/POST/PATCH/DELETE /api/regulasi`
- `GET/POST/PATCH/DELETE /api/pengguna`
- `GET /api/logs`
- `POST /api/survei`
- `POST /api/kontak`
- `POST /api/ppid`
- `GET/PATCH /api/ppid`
- `GET /api/stats`

Data tersimpan di `data/db.json`.

## Akun Demo

- Super Admin: `admin` / `admin123`
- Admin Kabupaten Tarakan: `admin.tarakan` / `kabupaten123`
- Admin Kota Nunukan: `admin.nunukan` / `kota123`
