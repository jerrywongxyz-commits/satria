const http = require("http");
const fs = require("fs/promises");
const path = require("path");
const crypto = require("crypto");

const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, "data");
const DB_FILE = path.join(DATA_DIR, "db.json");
const PORT = Number(process.env.PORT || 8765);
const HOST = process.env.HOST || "127.0.0.1";

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".webp": "image/webp",
  ".gif": "image/gif",
  ".svg": "image/svg+xml",
  ".mp4": "video/mp4",
  ".webm": "video/webm",
  ".ico": "image/x-icon",
};

const nowIso = () => new Date().toISOString();
const publicTicket = () => "SP-" + crypto.randomBytes(3).toString("hex").toUpperCase();
const hashPassword = (password) => crypto.createHash("sha256").update(String(password || "")).digest("hex");
const tokenHash = (token) => crypto.createHash("sha256").update(String(token || "")).digest("hex");

const ROLE_PERMISSIONS = {
  "Super Admin": ["*"],
  "Admin Provinsi": ["dashboard", "pengaduan", "berita", "agenda", "galeri", "profil", "regulasi", "ppid", "statistik", "log"],
  "Admin Kabupaten": ["dashboard", "pengaduan", "agenda", "galeri", "ppid", "statistik"],
  "Admin Kota": ["dashboard", "pengaduan", "agenda", "galeri", "ppid", "statistik"],
  Editor: ["dashboard", "berita", "agenda", "galeri", "profil", "regulasi"],
  Operator: ["dashboard", "pengaduan", "ppid"],
};

const ROLE_MUTATIONS = {
  "Super Admin": ["*"],
  "Admin Provinsi": ["pengaduan", "berita", "agenda", "galeri", "profil", "regulasi", "ppid", "cms"],
  "Admin Kabupaten": ["pengaduan", "agenda", "galeri", "ppid"],
  "Admin Kota": ["pengaduan", "agenda", "galeri", "ppid"],
  Editor: ["berita", "agenda", "galeri", "profil", "regulasi", "cms"],
  Operator: ["pengaduan", "ppid"],
};

function json(res, status, body) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
  });
  res.end(JSON.stringify(body, null, 2));
}

function notFound(res) {
  json(res, 404, { error: "Not found" });
}

function publicUser(user) {
  const permissions = ROLE_PERMISSIONS[user.peran] || ROLE_PERMISSIONS.Operator;
  return {
    id: user.id,
    nama: user.nama,
    username: user.username,
    peran: user.peran,
    akses: user.akses,
    email: user.email,
    wilayah: user.wilayah || "",
    status: user.status || "Aktif",
    permissions,
  };
}

function canAccess(user, resource, method) {
  if (!user) return false;
  if (user.peran === "Super Admin") return true;
  if (method === "GET") return true;
  return (ROLE_MUTATIONS[user.peran] || []).includes(resource);
}

function getBearer(req) {
  const header = req.headers.authorization || "";
  return header.startsWith("Bearer ") ? header.slice(7).trim() : "";
}

function findSessionUser(db, req) {
  const token = getBearer(req);
  if (!token) return null;
  const sessions = Array.isArray(db.sessions) ? db.sessions : [];
  const session = sessions.find((item) => item.tokenHash === tokenHash(token) && new Date(item.expiresAt).getTime() > Date.now());
  if (!session) return null;
  const user = (db.pengguna || []).find((item) => String(item.id) === String(session.userId) && item.status !== "Nonaktif");
  return user || null;
}

function sameScope(user, row) {
  if (!user || !user.wilayah || user.peran === "Super Admin" || user.peran === "Admin Provinsi") return true;
  const scope = String(user.wilayah).toLowerCase();
  const text = [row.wil, row.wilayah, row.lokasi, row.lok].filter(Boolean).join(" ").toLowerCase();
  return text.includes(scope);
}

async function readBody(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  if (!chunks.length) return {};
  const raw = Buffer.concat(chunks).toString("utf8");
  if (!raw.trim()) return {};
  try {
    return JSON.parse(raw);
  } catch {
    const err = new Error("Invalid JSON body");
    err.status = 400;
    throw err;
  }
}

async function readDb() {
  const raw = await fs.readFile(DB_FILE, "utf8");
  return JSON.parse(raw);
}

async function writeDb(db) {
  await fs.mkdir(DATA_DIR, { recursive: true });
  await fs.writeFile(DB_FILE, JSON.stringify(db, null, 2) + "\n", "utf8");
}

function list(db, key, query) {
  let data = Array.isArray(db[key]) ? [...db[key]] : [];
  if (query.get("status")) data = data.filter((item) => String(item.status || "").toLowerCase() === query.get("status").toLowerCase());
  if (query.get("cat")) data = data.filter((item) => String(item.cat || item.kat || "").toLowerCase() === query.get("cat").toLowerCase());
  if (query.get("q")) {
    const q = query.get("q").toLowerCase();
    data = data.filter((item) => JSON.stringify(item).toLowerCase().includes(q));
  }
  return data;
}

function requireFields(body, fields) {
  const missing = fields.filter((field) => !String(body[field] || "").trim());
  if (missing.length) {
    const err = new Error(`Field wajib belum diisi: ${missing.join(", ")}`);
    err.status = 400;
    throw err;
  }
}

function normalizeGaleriBody(body) {
  const title = String(body.judul || body.title || "").trim();
  const cat = String(body.kat || body.cat || "operasi").trim().toLowerCase();
  return {
    ...body,
    title,
    judul: title,
    cat,
    kat: cat,
    desc: String(body.desc || "").trim(),
    type: body.type === "video" ? "video" : "img",
    size: body.size || "wide",
    color: body.color || "0a5c8a/d6edf7",
    imageUrl: body.imageUrl || body.mediaUrl || "",
    mediaUrl: body.mediaUrl || body.imageUrl || "",
  };
}

function safeUploadExt(fileName, mime) {
  const fromName = path.extname(String(fileName || "")).toLowerCase();
  const allowed = new Set([".png", ".jpg", ".jpeg", ".webp", ".gif", ".mp4", ".webm"]);
  if (allowed.has(fromName)) return fromName;
  if (mime === "image/png") return ".png";
  if (mime === "image/webp") return ".webp";
  if (mime === "image/gif") return ".gif";
  if (mime === "video/mp4") return ".mp4";
  if (mime === "video/webm") return ".webm";
  return ".jpg";
}

async function saveUpload(body) {
  const mime = String(body.mime || body.type || "").toLowerCase();
  if (!/^image\/(png|jpe?g|webp|gif)$/.test(mime) && !/^video\/(mp4|webm)$/.test(mime)) {
    const err = new Error("Format file belum didukung. Gunakan JPG, PNG, WEBP, GIF, MP4, atau WEBM.");
    err.status = 400;
    throw err;
  }
  const raw = String(body.data || "");
  const base64 = raw.includes(",") ? raw.split(",").pop() : raw;
  const buffer = Buffer.from(base64, "base64");
  if (!buffer.length || buffer.length > 12 * 1024 * 1024) {
    const err = new Error("Ukuran file kosong atau melebihi 12MB.");
    err.status = 400;
    throw err;
  }
  const ext = safeUploadExt(body.fileName, mime);
  const dir = path.join(ROOT, "uploads");
  await fs.mkdir(dir, { recursive: true });
  const file = `${Date.now()}-${crypto.randomBytes(6).toString("hex")}${ext}`;
  await fs.writeFile(path.join(dir, file), buffer);
  return {
    url: `/uploads/${file}`,
    fileName: String(body.fileName || file),
    mime,
    size: buffer.length,
  };
}

async function handleApi(req, res, url) {
  const db = await readDb();
  const method = req.method || "GET";
  const parts = url.pathname.split("/").filter(Boolean);
  const resource = parts[1];
  const id = parts[2];
  const authUser = findSessionUser(db, req);

  if (method === "GET" && resource === "health") {
    return json(res, 200, { ok: true, service: "satpolpp-backend", time: nowIso() });
  }

  if (method === "POST" && resource === "login") {
    const body = await readBody(req);
    requireFields(body, ["username", "password"]);
    const user = (db.pengguna || []).find((item) => String(item.username || "").toLowerCase() === String(body.username).toLowerCase());
    if (!user || user.status === "Nonaktif" || user.passwordHash !== hashPassword(body.password)) {
      return json(res, 401, { error: "Username atau kata sandi salah." });
    }
    const token = crypto.randomBytes(32).toString("hex");
    const expiresAt = new Date(Date.now() + 8 * 60 * 60 * 1000).toISOString();
    if (!Array.isArray(db.sessions)) db.sessions = [];
    db.sessions = db.sessions.filter((item) => new Date(item.expiresAt).getTime() > Date.now() && String(item.userId) !== String(user.id));
    db.sessions.push({ id: crypto.randomUUID(), userId: user.id, tokenHash: tokenHash(token), createdAt: nowIso(), expiresAt });
    user.loginTerakhir = new Date().toLocaleString("id-ID", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
    await writeDb(db);
    return json(res, 200, { token, expiresAt, user: publicUser(user) });
  }

  if (method === "GET" && resource === "me") {
    return authUser ? json(res, 200, publicUser(authUser)) : json(res, 401, { error: "Belum login." });
  }

  if (method === "POST" && resource === "logout") {
    const bearerHash = tokenHash(getBearer(req));
    if (Array.isArray(db.sessions)) {
      db.sessions = db.sessions.filter((item) => item.tokenHash !== bearerHash);
      await writeDb(db);
    }
    return json(res, 200, { ok: true });
  }

  if (method === "POST" && resource === "upload") {
    if (!authUser) return json(res, 401, { error: "Sesi admin diperlukan." });
    const body = await readBody(req);
    requireFields(body, ["data"]);
    return json(res, 201, await saveUpload(body));
  }

  if (method === "GET" && resource === "stats") {
    const pengaduan = db.pengaduan || [];
    return json(res, 200, {
      pengaduan: {
        total: pengaduan.length,
        baru: pengaduan.filter((x) => x.status === "Baru").length,
        proses: pengaduan.filter((x) => x.status === "Proses").length,
        selesai: pengaduan.filter((x) => x.status === "Selesai").length,
      },
      survei: {
        total: (db.survei || []).length,
        rataRata: (db.survei || []).length
          ? Number(((db.survei || []).reduce((sum, x) => sum + Number(x.rating || 0), 0) / db.survei.length).toFixed(2))
          : 0,
      },
    });
  }

  const collectionMap = {
    pengaduan: "pengaduan",
    berita: "berita",
    agenda: "agenda",
    galeri: "galeri",
    regulasi: "regulasi",
    pengguna: "pengguna",
    logs: "logs",
    survei: "survei",
    kontak: "kontak",
    ppid: "ppid",
    cms: "cms",
  };
  const key = collectionMap[resource];
  if (!key) return notFound(res);

  const publicGetResources = new Set(["pengaduan", "berita", "agenda", "galeri", "regulasi", "survei", "logs", "cms"]);
  const publicPostResources = new Set(["pengaduan", "kontak", "ppid", "survei"]);
  const isPublicRequest = (method === "GET" && publicGetResources.has(resource) && resource !== "pengguna") || (method === "POST" && publicPostResources.has(resource));
  if (!isPublicRequest) {
    if (!authUser) return json(res, 401, { error: "Sesi admin diperlukan." });
    if (!canAccess(authUser, resource, method)) return json(res, 403, { error: "Hak akses tidak cukup untuk fitur ini." });
  }

  if (method === "GET") {
    if (resource === "pengaduan" && id) {
      const ticket = id.toUpperCase();
      const found = (db.pengaduan || []).find((item) => item.id === ticket);
      return found ? json(res, 200, found) : notFound(res);
    }
    if (id) {
      const found = (db[key] || []).find((item) => String(item.id) === String(id));
      return found ? json(res, 200, found) : notFound(res);
    }
    let rows = list(db, key, url.searchParams);
    if (authUser && ["Admin Kabupaten", "Admin Kota"].includes(authUser.peran) && ["pengaduan", "agenda"].includes(resource)) {
      rows = rows.filter((row) => sameScope(authUser, row));
    }
    if (resource === "pengguna") rows = rows.map(publicUser);
    return json(res, 200, rows);
  }

  if (method === "POST") {
    const body = await readBody(req);
    if (!Array.isArray(db[key])) db[key] = [];

    if (resource === "cms") {
      const cmsKey = String(body.key || body.id || "").trim();
      requireFields({ key: cmsKey, html: body.html }, ["key", "html"]);
      const idx = db.cms.findIndex((item) => String(item.key || item.id) === cmsKey);
      const item = {
        ...(idx >= 0 ? db.cms[idx] : { id: cmsKey, key: cmsKey, createdAt: nowIso() }),
        ...body,
        id: cmsKey,
        key: cmsKey,
        updatedAt: nowIso(),
      };
      if (idx >= 0) db.cms[idx] = item;
      else db.cms.unshift(item);
      if (db.logs) db.logs.unshift({ wkt: nowIso(), admin: authUser?.nama || "Sistem", aksi: "Update", modul: "PROFIL", detail: `Konten profil ${cmsKey} diperbarui`, ip: req.socket.remoteAddress });
      await writeDb(db);
      return json(res, idx >= 0 ? 200 : 201, item);
    }

    if (resource === "pengaduan") {
      requireFields(body, ["nama", "lokasi", "kategori", "uraian"]);
      const item = {
        id: publicTicket(),
        nama: String(body.nama).trim(),
        kontak: String(body.kontak || "").trim(),
        kat: String(body.kategori).trim(),
        lokasi: String(body.lokasi).trim(),
        wil: String(body.wilayah || body.lokasi || "").trim(),
        tgl: new Date().toLocaleDateString("id-ID", { day: "2-digit", month: "short", year: "numeric" }),
        status: "Baru",
        prio: body.prio || "Sedang",
        isi: String(body.uraian).trim(),
        riwayat: [{ aksi: "Dibuat", wkt: nowIso(), petugas: "Sistem", ket: "Pengaduan diterima dari website." }],
        createdAt: nowIso(),
      };
      db.pengaduan.unshift(item);
      db.logs.unshift({ wkt: nowIso(), admin: "Sistem", aksi: "Tambah", modul: "Pengaduan", detail: `Tiket ${item.id} dibuat`, ip: req.socket.remoteAddress });
      await writeDb(db);
      return json(res, 201, item);
    }

    if (resource === "kontak") requireFields(body, ["nama", "email", "pesan"]);
    if (resource === "ppid") requireFields(body, ["pemohon", "email", "info"]);
    if (resource === "survei") requireFields(body, ["rating"]);
    if (resource === "galeri" && !String(body.title || body.judul || "").trim()) requireFields(body, ["title"]);

    const item = {
      id: crypto.randomUUID(),
      ...(resource === "galeri" ? normalizeGaleriBody(body) : body),
      createdAt: nowIso(),
    };
    if (resource === "pengguna") {
      item.passwordHash = hashPassword(body.password || body.sandi || "admin123");
      item.akses = item.akses || (ROLE_PERMISSIONS[item.peran] || []).join(", ");
    }
    db[key].unshift(item);
    if (db.logs && resource !== "logs") db.logs.unshift({ wkt: nowIso(), admin: "Sistem", aksi: "Tambah", modul: resource.toUpperCase(), detail: `Data ${resource} baru`, ip: req.socket.remoteAddress });
    await writeDb(db);
    if (resource === "pengguna") return json(res, 201, publicUser(item));
    return json(res, 201, item);
  }

  if ((method === "PUT" || method === "PATCH") && id) {
    const body = await readBody(req);
    const idx = (db[key] || []).findIndex((item) => String(item.id) === String(id));
    if (resource === "cms" && idx < 0) {
      if (!Array.isArray(db.cms)) db.cms = [];
      const item = { id, key: body.key || id, ...body, createdAt: nowIso(), updatedAt: nowIso() };
      db.cms.unshift(item);
      if (db.logs) db.logs.unshift({ wkt: nowIso(), admin: authUser?.nama || "Sistem", aksi: "Update", modul: "PROFIL", detail: `Konten profil ${item.key} diperbarui`, ip: req.socket.remoteAddress });
      await writeDb(db);
      return json(res, 201, item);
    }
    if (idx < 0) return notFound(res);
    if (authUser && ["Admin Kabupaten", "Admin Kota"].includes(authUser.peran) && ["pengaduan", "agenda"].includes(resource) && !sameScope(authUser, db[key][idx])) {
      return json(res, 403, { error: "Data di luar wilayah akun ini." });
    }
    const patch = resource === "galeri" ? normalizeGaleriBody({ ...db[key][idx], ...body }) : body;
    if (resource === "pengguna" && (body.password || body.sandi)) {
      patch.passwordHash = hashPassword(body.password || body.sandi);
      delete patch.password;
      delete patch.sandi;
    }
    db[key][idx] = { ...db[key][idx], ...patch, updatedAt: nowIso() };
    await writeDb(db);
    if (resource === "pengguna") return json(res, 200, publicUser(db[key][idx]));
    return json(res, 200, db[key][idx]);
  }

  if (method === "DELETE" && id) {
    const idx = (db[key] || []).findIndex((item) => String(item.id) === String(id));
    if (idx < 0) return notFound(res);
    if (authUser && ["Admin Kabupaten", "Admin Kota"].includes(authUser.peran) && ["pengaduan", "agenda"].includes(resource) && !sameScope(authUser, db[key][idx])) {
      return json(res, 403, { error: "Data di luar wilayah akun ini." });
    }
    const [removed] = db[key].splice(idx, 1);
    await writeDb(db);
    return json(res, 200, removed);
  }

  json(res, 405, { error: "Method not allowed" });
}

async function serveStatic(req, res, url) {
  let pathname = decodeURIComponent(url.pathname);
  if (pathname === "/") pathname = "/satpolpp-kaltara.html";
  const target = path.resolve(ROOT, "." + pathname);
  if (!target.startsWith(ROOT)) {
    res.writeHead(403);
    return res.end("Forbidden");
  }
  try {
    const stat = await fs.stat(target);
    const file = stat.isDirectory() ? path.join(target, "index.html") : target;
    const data = await fs.readFile(file);
    res.writeHead(200, { "Content-Type": MIME[path.extname(file).toLowerCase()] || "application/octet-stream" });
    res.end(data);
  } catch {
    res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
    res.end("Not found");
  }
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url || "/", `http://${req.headers.host || `${HOST}:${PORT}`}`);
    if (url.pathname.startsWith("/api/")) return await handleApi(req, res, url);
    await serveStatic(req, res, url);
  } catch (err) {
    json(res, err.status || 500, { error: err.message || "Internal server error" });
  }
});

server.listen(PORT, HOST, () => {
  console.log(`Satpol PP backend ready: http://${HOST}:${PORT}`);
  console.log(`API health: http://${HOST}:${PORT}/api/health`);
});
